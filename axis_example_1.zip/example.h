#define TEST_SIZE 4

void example(int A, int *X);
